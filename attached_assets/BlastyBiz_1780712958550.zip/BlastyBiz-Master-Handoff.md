# BlastyBiz — Master Handoff
> Built by Dave (Fluba Designs LLC) and Ghost  
> HTML fixes applied June 2026  
> This document supersedes all previous handoff files  
> Stack: HTML/CSS/JS prototype → Firebase + Cloud Functions + Anthropic API
> Package: `BlastyBiz-Ready.zip` — 15 files

---

## Product

BlastyBiz is a local business marketing distribution tool. A business owner fills out one form, AI adapts their listing for every platform, and it either auto-posts or generates ready-to-paste copy depending on what each platform supports.

**Core Promise:** Enter your business information once. Review it. Distribute it everywhere.

**Target customer:** Brick and mortar local businesses — restaurants, shops, salons, contractors, service providers — who don't have time to manually post to multiple platforms.

**KISS Rule:** Every customer-facing screen must be understandable by a non-technical small business owner. Customers see outcomes. Admins see mechanics. Never show customers queue terminology, OAuth language, API errors, retry counts, or job IDs.

---

## Monetization

| Plan | Price | What's Included |
|------|-------|-----------------|
| Starter | Free | 3 listings/month, copy-paste platforms only, AI adaptation, photo uploads |
| Pro | $19/month | Unlimited listings, all platforms, auto-post, saved profile, full history |
| Agency | $99/month | Up to 10 businesses, everything in Pro, client dashboard, white label option |

These are the canonical prices. All files now reflect this. Stripe products must match exactly.

---

## Canonical File Names

Use exactly these. No version suffixes. No duplicates.

```
BlastyBiz-Home.html
BlastyBiz-Login.html
BlastyBiz-Onboarding.html
BlastyBiz.html
BlastyBiz-Dashboard.html
BlastyBiz-Listing-Preview.html
BlastyBiz-Publishing-Status.html
BlastyBiz-Admin.html
BlastyBiz-Admin-Queue-Manager.html
BlastyBiz-Admin-Failed-Jobs.html
BlastyBiz-Admin-Users.html
BlastyBiz-Admin-Subscriptions.html
BlastyBiz-Admin-Platform-Health.html
BlastyBiz-Admin-Logs.html
```

Forbidden patterns: `-1.html`, `-2.html`, `-3.html`, `_v1`, `_final`, duplicate copies.

---

## Canonical User Flow

```
BlastyBiz-Home.html
    → BlastyBiz-Login.html
        → BlastyBiz-Onboarding.html     (first time only)
            → BlastyBiz-Dashboard.html  (every login after)
                → BlastyBiz.html        (create listing)
                    → POST /api/adaptListing
                        → BlastyBiz-Listing-Preview.html  (review + approve)
                            → POST /api/approveDraft
                                → BlastyBiz-Publishing-Status.html
```

## Canonical Admin Flow

```
BlastyBiz-Admin.html
    → BlastyBiz-Admin-Queue-Manager.html
    → BlastyBiz-Admin-Failed-Jobs.html
    → BlastyBiz-Admin-Users.html
    → BlastyBiz-Admin-Subscriptions.html
    → BlastyBiz-Admin-Platform-Health.html
    → BlastyBiz-Admin-Logs.html
```

---

## HTML Fixes Applied in This Package

All 12 HTML-only fixes have been made. These are confirmed and verified.

| # | Fix | File |
|---|-----|------|
| 1 | All 5 homepage CTAs now route to `BlastyBiz-Login.html` | `BlastyBiz-Home.html` |
| 2 | Homepage FAQ corrected — Nextdoor removed from auto-post list | `BlastyBiz-Home.html` |
| 3 | Onboarding final redirect now goes to `BlastyBiz-Dashboard.html` | `BlastyBiz-Onboarding.html` |
| 4 | Dashboard broken onboarding link fixed to `BlastyBiz-Onboarding.html` | `BlastyBiz-Dashboard.html` |
| 5 | Queue Manager added to Admin Dashboard header nav | `BlastyBiz-Admin.html` |
| 6 | Queue Manager now appears in its own nav bar | `BlastyBiz-Admin-Queue-Manager.html` |
| 7 | LinkedIn removed from Publishing Status page, count updated to 6 of 8 | `BlastyBiz-Publishing-Status.html` |
| 8 | Nextdoor changed to `type: 'manual'`, TikTok removed, Bing Places added to platform registry | `BlastyBiz.html` |
| 8b | Bing Places added to PLATFORM_RULES with 1500 char limit | `BlastyBiz.html` |
| 9 | Nextdoor connect card in onboarding Step 5 changed from Auto-Post to Copy & Paste | `BlastyBiz-Onboarding.html` |
| 10 | Admin Subscriptions plan pricing normalized to canonical (Starter $0 / Pro $19 / Agency $99) | `BlastyBiz-Admin-Subscriptions.html` |
| 11 | Email field added to Profile tab (form, saveProfile, loadProfile) | `BlastyBiz.html` |
| 12 | `--border` and `--muted` tokens normalized to `#1E2E1E` / `#587058` across all older files | `BlastyBiz-Home.html`, `BlastyBiz-Login.html`, `BlastyBiz-Onboarding.html` |

---

## What Rep Still Needs to Do

These require backend and cannot be done in HTML prototypes.

### Phase 1 — Foundation (do first)
- [ ] Create Firebase project
- [ ] Enable Auth: Email/Password, Google, Facebook
- [ ] Create Firestore database (production mode, us-east1), initialize all canonical collections
- [ ] Enable Firebase Storage with auth rules
- [ ] Add Firebase SDK to all app pages
- [ ] Add `onAuthStateChanged` auth guard to all app pages
- [ ] Wire auth calls in `BlastyBiz-Login.html` — replace all `setTimeout` placeholders with Firebase Auth
- [ ] Post-auth routing: onboarded users → `BlastyBiz-Dashboard.html`, new users → `BlastyBiz-Onboarding.html`
- [ ] Swap all localStorage to Firestore (see localStorage swap section below)

### Phase 2 — Core AI Flow
- [ ] Deploy `adaptListing` Cloud Function — fixes the CORS spinning bug in `BlastyBiz.html`
- [ ] Replace direct `fetch('https://api.anthropic.com/v1/messages', ...)` in `runAdaptation()` with `fetch('/api/adaptListing', ...)`
- [ ] Deploy `uploadImage` Cloud Function, wire to photo upload
- [ ] Deploy `resolveCategories` Cloud Function, wire to onboarding Step 2
- [ ] Wire `BlastyBiz-Listing-Preview.html` to read from `listingDrafts` Firestore collection
- [ ] Deploy `approveDraft` Cloud Function
- [ ] Wire "Approve & Continue" button to call `approveDraft`, create publishJobs
- [ ] Replace all `alert()` stubs in Listing Preview with real functions
- [ ] Replace `deployPlatform()` setTimeout in `BlastyBiz.html` with Cloud Function calls

### Phase 3 — Status & Queue
- [ ] Restyle `BlastyBiz-Publishing-Status.html` to Fluba design system (currently Arial/white)
- [ ] Wire Publishing Status to read from `publishJobs` Firestore collection
- [ ] Wire Admin Queue Manager to read from `publishJobs`
- [ ] Wire Admin Dashboard mock data to Firestore

### Phase 4 — Billing
- [ ] Create Stripe account, set up Pro ($19/month) and Agency ($99/month) products
- [ ] Deploy `createCheckoutSession` + `stripeWebhook` Cloud Functions
- [ ] Register Stripe webhook endpoint
- [ ] Enforce subscription gating (Starter: 3 listings max)

### Phase 5 — Admin Wiring
- [ ] Wire all admin pages to Firestore: `publishJobs`, `activityLogs`, `users`, `subscriptions`, `businesses`
- [ ] Wire Queue Manager retry/resolve actions to write back to `publishJobs`
- [ ] Wire Admin Users, Subscriptions, Platform Health, Logs, Failed Jobs to live data

### Phase 6 — Platform APIs (as approvals land)
- [ ] Google OAuth + `postToGoogle` Cloud Function
- [ ] Meta OAuth + `postToFacebook` + `postToInstagram` Cloud Functions
- [ ] Bing Places + `postToBing` Cloud Function
- [ ] Apple Maps + `postToAppleMaps` Cloud Function

### Phase 7 — Launch
- [ ] Privacy Policy page live (required for Meta + Google API approvals)
- [ ] Terms of Service page live
- [ ] Firebase Hosting configured
- [ ] Custom domain connected
- [ ] Full end-to-end flow tested

---

## Design System

All customer-facing pages now use consistent tokens.

| Token | Value | Usage |
|-------|-------|-------|
| `--green` | `#00C853` | Primary accent, CTAs, active states |
| `--dark` | `#070D07` | Page background |
| `--card` | `#0D160D` | Card backgrounds |
| `--silver` | `#7AB87A` | Secondary text |
| `--light` | `#EEF7EE` | Primary text |
| `--border` | `#1E2E1E` | Borders, dividers — normalized across all files |
| `--muted` | `#587058` | Placeholder, disabled — normalized across all files |
| `--danger` | `#FF4444` | Error states |
| `--warn` | `#FFA726` | Warning, manual platform labels |
| `--blue` | `#54A8FF` | Info states |

**Fonts:** Bebas Neue (display/headers/logo/numbers) · DM Sans (body)  
**Viewport:** All app pages use `100dvh` — do not use `100vh`  
**Admin light theme:** `BlastyBiz-Admin-Queue-Manager.html` and `BlastyBiz-Admin-Logs.html` use intentional white/slate theme — do not apply dark theme to these two files

---

## Platform Capability Matrix

Never represent a platform as automated unless marked `full_auto` or `partial_auto`.

| Platform | Capability | Customer Label | MVP |
|----------|-----------|----------------|-----|
| Google Business Profile | `full_auto` | Connected / Live / Needs reconnect | ✅ |
| Facebook Page | `partial_auto` | Connected / Live / Needs reconnect | ✅ |
| Instagram Business | `partial_auto` | Connected / Prepared / Needs action | ✅ |
| Bing Places | `partial_auto` | Prepared / Live / Needs action | ✅ |
| Apple Maps | `partial_auto` | Prepared / Submitted / Needs action | ✅ |
| Yelp | `partial_auto` | Prepared / Needs action | ✅ hybrid |
| Nextdoor | `manual_assisted` | Action needed | ✅ manual |
| Craigslist | `manual_assisted` | Action needed | ✅ manual |
| Facebook Marketplace | `manual_assisted` | Action needed | ✅ manual |
| TikTok | `unsupported` | — | ❌ post-MVP — removed from registry |
| LinkedIn | `unsupported` | — | ❌ not in scope — removed from Publishing Status |
| Thumbtack | `manual_assisted` | Prepared / Needs action | ❌ post-MVP |
| Angi | `manual_assisted` | Prepared / Needs action | ❌ post-MVP |
| Alignable | `manual_assisted` | Prepared / Needs action | ❌ post-MVP |

---

## Firestore Schema

### Canonical Collections — do not add outside this list
```
users / businesses / platformConnections / listingDrafts
publishJobs / subscriptions / activityLogs / reviews / reports
```

### users/{uid}
```json
{
  "uid": "", "email": "", "name": "",
  "plan": "starter|pro|agency", "planActive": false,
  "onboarded": false, "createdAt": ""
}
```

### businesses/{businessId}
```json
{
  "uid": "", "name": "", "ownerName": "", "phone": "", "email": "",
  "website": "", "category": "",
  "platformCats": { "fbmarket": "", "craigslist": "", "yelp": "", "thumbtack": "", "angi": "", "alignable": "", "applemaps": "" },
  "address": "", "city": "", "state": "",
  "days": ["Mon","Tue","Wed","Thu","Fri","Sat"],
  "openTime": "09:00", "closeTime": "17:00", "hours": "Mon–Sat 9am–5pm",
  "tone": "friendly", "special": "", "createdAt": ""
}
```

### listingDrafts/{draftId}
```json
{
  "businessId": "", "uid": "", "offer": "", "price": "", "imageUrls": [],
  "adaptations": { "google": "", "facebook": "", "instagram": "", "bing": "", "applemaps": "", "yelp": "", "nextdoor": "", "craigslist": "", "fbmarket": "" },
  "status": "draft|approved|rejected", "createdAt": "", "approvedAt": ""
}
```

### publishJobs/{jobId}
```json
{
  "jobId": "", "businessId": "", "uid": "", "draftId": "",
  "platform": "google",
  "capabilityLevel": "full_auto|partial_auto|manual_assisted|unsupported",
  "jobType": "publish_listing",
  "status": "pending|running|success|failed|retry_pending|manual_required|manual_completed|customer_reconnect_required|paused|closed",
  "attempts": 0, "maxAttempts": 3,
  "customerLabel": "Waiting to publish",
  "customerVisibleMessage": "Your Google Business listing is waiting to publish.",
  "adminError": "", "payload": {}, "apiResponse": {},
  "manualInstructions": "", "customerNotified": false,
  "createdAt": "", "updatedAt": "", "completedAt": ""
}
```

### subscriptions/{uid}
```json
{
  "uid": "", "stripeCustomerId": "", "stripeSubscriptionId": "",
  "plan": "starter|pro|agency", "status": "active|past_due|canceled|trialing",
  "currentPeriodEnd": "", "aiActionsUsed": 0, "generatedPostsUsed": 0
}
```

### platformConnections/{businessId}_{platformId}
```json
{
  "businessId": "",
  "uid": "",
  "platform": "google",
  "capabilityLevel": "full_auto|partial_auto|manual_assisted|unsupported",
  "connected": false,
  "accessToken": "",
  "refreshToken": "",
  "tokenExpiry": "",
  "platformAccountId": "",
  "status": "connected|disconnected|error|pending",
  "updatedAt": ""
}
```

**Note:** Document ID is `{businessId}_{platformId}` — e.g. `abc123_google`. One document per business per platform. Query by `businessId` to get all platform connections for a business. This is separate from `platformCats` (the category mapping object stored inside the `businesses` document).

### activityLogs/{logId}
```json
{
  "uid": "",
  "businessId": "",
  "level": "info|success|warning|error",
  "type": "auth|business|draft|publish_job|billing|platform|system",
  "message": "",
  "relatedCollection": "",
  "relatedId": "",
  "createdAt": ""
}
```

### reviews/{reviewId}
```json
{
  "businessId": "",
  "uid": "",
  "platform": "google",
  "reviewText": "",
  "rating": 0,
  "reviewerName": "",
  "reviewDate": "",
  "responseText": "",
  "respondedAt": "",
  "createdAt": ""
}
```

### reports/{reportId}
```json
{
  "uid": "",
  "businessId": "",
  "type": "performance|billing|platform_health",
  "period": "",
  "data": {},
  "createdAt": ""
}
```

### platformConnections/{businessId}_{platformId}
```json
{
  "businessId": "",
  "uid": "",
  "platform": "google",
  "capabilityLevel": "full_auto|partial_auto|manual_assisted|unsupported",
  "connected": false,
  "accessToken": "",
  "refreshToken": "",
  "tokenExpiry": "",
  "platformAccountId": "",
  "status": "connected|disconnected|error|pending",
  "updatedAt": ""
}
```

**Note:** Document ID is `{businessId}_{platformId}` e.g. `abc123_google`. One document per business per platform. This is separate from `platformCats` — the category mapping object stored inside the `businesses` document.

### activityLogs/{logId}
```json
{
  "uid": "",
  "businessId": "",
  "level": "info|success|warning|error",
  "type": "auth|business|draft|publish_job|billing|platform|system",
  "message": "",
  "relatedCollection": "",
  "relatedId": "",
  "createdAt": ""
}
```

### reviews/{reviewId}
```json
{
  "businessId": "",
  "uid": "",
  "platform": "google",
  "reviewText": "",
  "rating": 0,
  "reviewerName": "",
  "reviewDate": "",
  "responseText": "",
  "respondedAt": "",
  "createdAt": ""
}
```

### reports/{reportId}
```json
{
  "uid": "",
  "businessId": "",
  "type": "performance|billing|platform_health",
  "period": "",
  "data": {},
  "createdAt": ""
}
```

---

## Canonical Naming Reference

This is the single source of truth for every ID, key, field name, and collection name used across all files. Rep must use these exact names — no variations, no guessing.

### Platform IDs
These are the exact string IDs used in the platform registry, PLATFORM_CATS, listingDrafts adaptations, publishJobs, and platformConnections. They never change.

| ID | Used For |
|----|---------|
| `google` | Google Business Profile |
| `facebook` | Facebook Page |
| `instagram` | Instagram Business |
| `bing` | Bing Places |
| `applemaps` | Apple Maps Connect |
| `yelp` | Yelp |
| `nextdoor` | Nextdoor |
| `craigslist` | Craigslist |
| `fbmarket` | Facebook Marketplace |
| `thumbtack` | Thumbtack (post-MVP) |
| `angi` | Angi (post-MVP) |
| `alignable` | Alignable (post-MVP) |

### Business Profile Field Names
These are the canonical Firestore field names. All HTML files have been updated to match.

| Canonical Field | Old Prototype Name | Where Used |
|----------------|-------------------|------------|
| `name` | `name` | All files ✅ |
| `ownerName` | `owner` | Fixed in onboarding ✅ |
| `category` | `cat` | Fixed in onboarding + dashboard ✅ |
| `platformCats` | `platformCats` | All files ✅ |
| `phone` | `phone` | All files ✅ |
| `email` | `email` | All files ✅ |
| `address` | `address` | All files ✅ |
| `city` | `city` | All files ✅ |
| `state` | `state` | All files ✅ |
| `days` | `days` | All files ✅ |
| `openTime` | `openTime` | All files ✅ |
| `closeTime` | `closeTime` | All files ✅ |
| `hours` | `hours` | All files ✅ |
| `tone` | `tone` | All files ✅ |
| `special` | `special` | All files ✅ |
| `website` | `website` | All files ✅ |

### localStorage Keys (prototype only — swap to Firestore)

| Key | Maps To |
|-----|---------|
| `ll_profile` | `businesses/{businessId}` |
| `ll_platforms` | `platformConnections/{businessId}_{platformId}` |
| `ll_history` | `publishJobs` collection |
| `ll_draft` | `listingDrafts/{draftId}` |

### Firestore Collection Names

| Collection | Purpose |
|-----------|---------|
| `users` | Auth user records |
| `businesses` | Business profiles |
| `platformConnections` | One doc per business per platform |
| `listingDrafts` | AI-generated drafts awaiting approval |
| `publishJobs` | Distribution jobs — source of truth for all status |
| `subscriptions` | Stripe subscription state |
| `activityLogs` | Admin-visible system events |
| `reviews` | Customer reviews from platforms |
| `reports` | Performance/billing reports |

### platformConnections Document ID Format
`{businessId}_{platformId}` — e.g. `abc123_google`, `abc123_fbmarket`  
Never store all platform connections in a single document or array.

### platformCats vs platformConnections
These are two different things:
- `platformCats` — object inside `businesses` document, maps platform ID to the best category for that platform (e.g. `{ google: "Aerial Photographer", yelp: "Photography" }`)
- `platformConnections` — separate Firestore collection, one document per business per platform, stores OAuth tokens and connection status

### Cloud Function Names

| Function | Endpoint | Purpose |
|----------|---------|---------|
| `adaptListing` | `POST /api/adaptListing` | AI adapts listing for all platforms |
| `resolveCategories` | `POST /api/resolveCategories` | AI resolves best category per platform |
| `approveDraft` | `POST /api/approveDraft` | Creates publishJobs from approved draft |
| `uploadImage` | `POST /api/uploadImage` | Uploads image to Firebase Storage |
| `postToGoogle` | internal | Posts to Google Business Profile API |
| `postToFacebook` | internal | Posts to Facebook Page via Meta Graph API |
| `postToInstagram` | internal | Posts to Instagram via Meta Graph API |
| `createCheckoutSession` | `POST /api/createCheckoutSession` | Creates Stripe checkout |
| `stripeWebhook` | `POST /api/stripeWebhook` | Handles Stripe subscription events |

### HTML Form Element IDs

**Create tab (`BlastyBiz.html`):**
`biz-name`, `biz-category`, `biz-offer`, `biz-price`, `biz-phone`, `biz-address`, `biz-website`, `biz-hours`

**Profile tab (`BlastyBiz.html`):**
`profile-name`, `profile-cat`, `profile-phone`, `profile-email`, `profile-address`, `profile-website`, `profile-hours`, `profile-tone`

**Onboarding (`BlastyBiz-Onboarding.html`):**
`s-name`, `s-owner`, `s-phone`, `s-biztype`, `s-address`, `s-city`, `s-state`, `s-open`, `s-close`, `s-email`, `s-website`, `s-special`

### File Routing Map

| From | Condition | To |
|------|-----------|-----|
| Home | any CTA | Login |
| Login | sign in, onboarded | Dashboard |
| Login | sign in, not onboarded | Onboarding |
| Login | sign up | Onboarding |
| Onboarding | complete | Dashboard |
| Dashboard | create listing | BlastyBiz.html |
| BlastyBiz.html | after AI adapts | Listing Preview |
| Listing Preview | approved | Publishing Status |
| All app pages | not signed in | Login |
| All admin pages | not admin role | Login |

---

## localStorage → Firestore Swap

Every localStorage key in the prototype maps directly to Firestore.

```javascript
// ll_profile → businesses/{businessId}
localStorage.setItem('ll_profile', JSON.stringify(profile))
→ await setDoc(doc(db, 'businesses', businessId), profile)

// ll_platforms → platformConnections/{connectionId}
localStorage.setItem('ll_platforms', JSON.stringify(platforms))
→ await setDoc(doc(db, 'platformConnections', connectionId), { list: platforms })

// ll_history → publishJobs collection
localStorage.setItem('ll_history', JSON.stringify(history))
→ await addDoc(collection(db, 'publishJobs'), jobData)

// ll_draft → listingDrafts/{draftId}
localStorage.setItem('ll_draft', JSON.stringify(draft))
→ await setDoc(doc(db, 'listingDrafts', draftId), draft)
```

---

## Firebase Setup

```bash
npm install firebase
npm install -g firebase-tools
firebase init functions
cd functions && npm install @anthropic-ai/sdk axios stripe
```

Enable: Authentication (Email/Password, Google, Facebook), Firestore (production, us-east1), Storage

### Storage rules
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{uid}/{allPaths=**} {
      allow read, write: if request.auth.uid == uid;
    }
  }
}
```

### SDK init — add to every app page
```html
<!-- Use CDN imports for plain HTML files. Switch to npm/bundler when converting to React/bundled app. -->
<script type="module">
  import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
  import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
  import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
  import { getStorage } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js';

  const app = initializeApp({
    apiKey: "YOUR_API_KEY",
    authDomain: "blastybiz.firebaseapp.com",
    projectId: "blastybiz",
    storageBucket: "blastybiz.appspot.com",
    messagingSenderId: "YOUR_ID",
    appId: "YOUR_APP_ID"
  });

  const auth = getAuth(app);
  const db = getFirestore(app);
  const storage = getStorage(app);

  // Auth guard — every app page except Home and Login
  onAuthStateChanged(auth, user => {
    if (!user) window.location.href = 'BlastyBiz-Login.html';
  });
</script>
```

---

## Auth Wiring — BlastyBiz-Login.html

Replace all setTimeout placeholders:

```javascript
import { signInWithEmailAndPassword, createUserWithEmailAndPassword,
  GoogleAuthProvider, FacebookAuthProvider,
  signInWithPopup, sendPasswordResetEmail } from 'firebase/auth';
import { getDoc, setDoc, doc } from 'firebase/firestore';

// Sign In — replace handleSignIn() setTimeout
await signInWithEmailAndPassword(auth, email, password);
const snap = await getDoc(doc(db, 'users', user.uid));
const userData = snap.exists() ? snap.data() : {};
window.location.href = userData.onboarded
  ? 'BlastyBiz-Dashboard.html'
  : 'BlastyBiz-Onboarding.html';

// Sign Up — replace handleSignUp() setTimeout
const cred = await createUserWithEmailAndPassword(auth, email, password);
await setDoc(doc(db, 'users', cred.user.uid), {
  uid: cred.user.uid, name, email,
  plan: selectedPlanId, planActive: false, onboarded: false,
  createdAt: new Date()
});
window.location.href = 'BlastyBiz-Onboarding.html';

// Google — replace handleGoogle()
await signInWithPopup(auth, new GoogleAuthProvider());

// Facebook — replace handleFacebook()
await signInWithPopup(auth, new FacebookAuthProvider());

// Password Reset — replace handleReset()
await sendPasswordResetEmail(auth, email);
```

---

## Cloud Functions

**Critical rule: Never call Anthropic or any platform API directly from the browser.**

### Function 1: adaptListing — Deploy first. Fixes CORS spinning bug.

Move the full prompt from `runAdaptation()` in `BlastyBiz.html` to this function. Preserve the prompt text exactly.

```javascript
const { onRequest } = require('firebase-functions/v2/https');
const Anthropic = require('@anthropic-ai/sdk');

exports.adaptListing = onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') { res.status(204).send(''); return; }

  const { listing, platforms, tone, platformCats } = req.body;
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  const PLATFORM_RULES = {
    google:     { maxChars: 1500, notes: 'Professional, keyword-rich, include all contact info' },
    facebook:   { maxChars: 2000, notes: 'Engaging, emoji welcome, strong call to action' },
    instagram:  { maxChars: 2200, notes: 'Caption style, 3-5 hashtags at end' },
    bing:       { maxChars: 1500, notes: 'Professional, complete business info, include hours and location' },
    nextdoor:   { maxChars: 1000, notes: 'Warm, community-focused, mention neighborhood' },
    fbmarket:   { maxChars: 1000, notes: 'Clear title, price prominent, location, contact' },
    craigslist: { maxChars: 1500, notes: 'Structured sections, plain text, no emoji' },
    yelp:       { maxChars: 1500, notes: 'Descriptive, highlight uniqueness and atmosphere' },
    applemaps:  { maxChars: 500,  notes: 'Factual, complete, hours and category accurate' },
    alignable:  { maxChars: 800,  notes: 'B2B professional, what you offer other businesses' },
    thumbtack:  { maxChars: 800,  notes: 'Service-focused, expertise, reliability' },
    angi:       { maxChars: 800,  notes: 'Trade-specific, licensed/insured if applicable' },
  };

  const platformList = platforms.map(p => ({
    id: p.id, name: p.name, type: p.type,
    rules: PLATFORM_RULES[p.id] || {}
  }));

  const prompt = `You are a local business marketing expert. Adapt the following business listing for each platform listed. Return ONLY a valid JSON object — no markdown, no explanation, no backticks.

BUSINESS INFO:
- Name: ${listing.name || 'Local Business'}
- Category: ${listing.category || 'General'}
- Description: ${listing.offer}
- Price/Range: ${listing.price || 'not specified'}
- Phone: ${listing.phone || 'not provided'}
- Address: ${listing.address || 'not provided'}
- Website: ${listing.website || 'none'}
- Hours: ${listing.hours || 'not provided'}
- Images attached: ${listing.imageCount > 0 ? listing.imageCount + ' photo(s)' : 'none'}
- Preferred tone: ${tone}

PLATFORMS TO ADAPT FOR:
${platformList.map(p => `- ${p.id}: ${p.name} (${p.type === 'api' ? 'auto-post' : 'copy-paste'})${p.rules.maxChars ? ', max ' + p.rules.maxChars + ' chars' : ''}${p.rules.notes ? ', note: ' + p.rules.notes : ''}`).join('\n')}

Return this exact JSON structure:
{
  "adaptations": {
    "PLATFORM_ID": "adapted text here"
  }
}`;

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages: [{ role: 'user', content: prompt }]
  });

  const parsed = JSON.parse(response.content[0].text.replace(/```json|```/g, '').trim());
  res.json(parsed);
});
```

**Replace in `BlastyBiz.html` `runAdaptation()`:**
```javascript
// FROM (causes CORS bug + exposes key)
const response = await fetch('https://api.anthropic.com/v1/messages', { ... });

// TO
const response = await fetch('https://YOUR_REGION-blastybiz.cloudfunctions.net/adaptListing', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    listing: { name, category, offer, price, phone, address, website, hours, imageCount: selectedImages.length },
    platforms: enabledPlatforms,
    tone,
    platformCats: profile.platformCats || {}
  })
});
```

---

### Function 2: resolveCategories

Upgrades the static keyword scorer in onboarding Step 2. Pass the `PLATFORM_CATS` object as `platformCatLists`.

```javascript
exports.resolveCategories = onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  const { description, platformCatLists } = req.body;
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  const prompt = `Given this business: "${description}"
Pick the best matching category for each platform from the lists provided.
Return ONLY valid JSON, no markdown: { "categories": { "platformId": "category name" } }

${Object.entries(platformCatLists).map(([id, cats]) => `${id}: ${cats.join(', ')}`).join('\n')}`;

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514', max_tokens: 500,
    messages: [{ role: 'user', content: prompt }]
  });

  const parsed = JSON.parse(response.content[0].text.replace(/```json|```/g, '').trim());
  res.json(parsed);
});
```

---

### Function 3: approveDraft

Called from "Approve & Continue" in `BlastyBiz-Listing-Preview.html`. Creates one publishJob per platform.

```javascript
exports.approveDraft = onRequest(async (req, res) => {
  const { draftId, businessId, uid, platforms } = req.body;
  const db = getFirestore();
  const batch = db.batch();

  batch.update(doc(db, 'listingDrafts', draftId), {
    status: 'approved', approvedAt: serverTimestamp()
  });

  platforms.forEach(platform => {
    const jobRef = doc(collection(db, 'publishJobs'));
    const isManual = ['manual_assisted', 'unsupported'].includes(platform.capabilityLevel);
    batch.set(jobRef, {
      jobId: jobRef.id, businessId, uid, draftId,
      platform: platform.id,
      capabilityLevel: platform.capabilityLevel,
      jobType: 'publish_listing',
      status: isManual ? 'manual_required' : 'pending',
      attempts: 0, maxAttempts: 3,
      customerLabel: isManual ? 'Action needed' : 'Waiting to publish',
      customerVisibleMessage: isManual
        ? `Your ${platform.name} listing is ready — you need to post it manually.`
        : `Your ${platform.name} listing is waiting to publish.`,
      manualInstructions: platform.manualInstructions || '',
      adminError: '', payload: platform.adaptedContent || {},
      apiResponse: {}, customerNotified: false,
      createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });
  });

  await batch.commit();
  res.json({ success: true });
});
```

---

### Function 4: uploadImage

Images are `File` objects in memory — never base64 in prototype. Convert to base64 before POSTing.

```javascript
exports.uploadImage = onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  const { uid, imageData, fileName, mimeType } = req.body;
  const bucket = getStorage().bucket();
  const file = bucket.file(`users/${uid}/images/${Date.now()}_${fileName}`);
  await file.save(Buffer.from(imageData, 'base64'), { contentType: mimeType });
  const [url] = await file.getSignedUrl({ action: 'read', expires: '03-01-2500' });
  res.json({ url });
});
```

---

### Functions 5–7: Platform Posting

```javascript
// Google Business Profile
exports.postToGoogle = onRequest(async (req, res) => {
  const { content, imageUrls, accessToken, locationId, accountId } = req.body;
  const response = await axios.post(
    `https://mybusiness.googleapis.com/v4/accounts/${accountId}/locations/${locationId}/localPosts`,
    { languageCode: 'en-US', summary: content,
      media: imageUrls.map(url => ({ mediaFormat: 'PHOTO', sourceUrl: url })) },
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  res.json({ success: true, postId: response.data.name });
});

// Facebook Page
exports.postToFacebook = onRequest(async (req, res) => {
  const { content, accessToken, pageId } = req.body;
  const response = await axios.post(
    `https://graph.facebook.com/v18.0/${pageId}/feed`,
    { message: content, access_token: accessToken }
  );
  res.json({ success: true, postId: response.data.id });
});

// Instagram (two-step: create then publish)
exports.postToInstagram = onRequest(async (req, res) => {
  const { caption, imageUrl, accessToken, igUserId } = req.body;
  const media = await axios.post(
    `https://graph.facebook.com/v18.0/${igUserId}/media`,
    { image_url: imageUrl, caption, access_token: accessToken }
  );
  const publish = await axios.post(
    `https://graph.facebook.com/v18.0/${igUserId}/media_publish`,
    { creation_id: media.data.id, access_token: accessToken }
  );
  res.json({ success: true, postId: publish.data.id });
});

// Bing Places and Apple Maps — implement after API approvals
```

---

### Function 8: createCheckoutSession

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.createCheckoutSession = onRequest(async (req, res) => {
  const { plan, uid, email } = req.body;
  const prices = {
    pro: 'price_YOUR_PRO_PRICE_ID',      // $19/month
    agency: 'price_YOUR_AGENCY_PRICE_ID' // $99/month
  };
  const session = await stripe.checkout.sessions.create({
    customer_email: email,
    line_items: [{ price: prices[plan], quantity: 1 }],
    mode: 'subscription',
    success_url: 'https://blastybiz.com/dashboard?success=1',
    cancel_url: 'https://blastybiz.com/pricing',
    metadata: { uid }
  });
  res.json({ url: session.url });
});
```

### Function 9: stripeWebhook

```javascript
exports.stripeWebhook = onRequest(async (req, res) => {
  const event = stripe.webhooks.constructEvent(
    req.rawBody, req.headers['stripe-signature'],
    process.env.STRIPE_WEBHOOK_SECRET
  );
  if (['customer.subscription.created','customer.subscription.updated'].includes(event.type)) {
    const uid = event.data.object.metadata.uid;
    const plan = event.data.object.items.data[0].price.nickname;
    await setDoc(doc(db, 'users', uid), { plan, planActive: true }, { merge: true });
    await setDoc(doc(db, 'subscriptions', uid), {
      stripeCustomerId: event.data.object.customer,
      stripeSubscriptionId: event.data.object.id,
      plan, status: event.data.object.status,
      currentPeriodEnd: new Date(event.data.object.current_period_end * 1000)
    }, { merge: true });
  }
  res.json({ received: true });
});
```

---

## Environment Variables

```bash
firebase functions:config:set \
  anthropic.key="sk-ant-..." \
  google.client_id="..." \
  google.client_secret="..." \
  meta.app_id="..." \
  meta.app_secret="..." \
  bing.api_key="..." \
  apple.key_id="..." \
  apple.team_id="..." \
  nextdoor.client_id="..." \
  nextdoor.client_secret="..." \
  stripe.secret_key="sk_live_..." \
  stripe.webhook_secret="whsec_..."
```

**NEVER put any key in any HTML file.**

---

## Platform API Applications — Start Now

| Platform | Lead Time | Notes |
|----------|-----------|-------|
| Meta (Facebook + Instagram) | 4–6 weeks | **Start immediately.** Needs live privacy policy URL + working OAuth demo. Permissions needed: `pages_manage_posts`, `instagram_basic`, `instagram_content_publish`. May require screen recording. |
| Google My Business | 2–4 weeks | One Google Cloud project for all 7 Fluba businesses. Each needs verified Google Business Profile (postcard = 5–7 days each). Enable: My Business Business Information API + Account Management API. Scope: `business.manage`. |
| Nextdoor Partner API | Weeks–months | Invite-only. Submit partner application now regardless of dev status. |
| Bing Places | 1–2 weeks | Apply after Firebase is live |
| Apple Business Connect | 1–2 weeks | Apply after Firebase is live |
| Yelp | Days | Apply anytime |

---

## Multi-Business Architecture (Agency Tier)

### How It Works

Dave owns 7 businesses under one Firebase Auth account. The Agency plan ($99/month) allows up to 10 businesses. One login, one app, full context switching between businesses.

The data model already supports this — every `businesses` document has a `uid` field. Multiple business documents can share the same `uid`. All downstream collections (`platformConnections`, `listingDrafts`, `publishJobs`) reference `businessId`, so each business's data is completely isolated.

### Dave's 7 Businesses

| businessId | Name | Avatar |
|-----------|------|--------|
| `qrgear` | QR Gear | 📱 |
| `kingdomconnects` | Kingdom Connects | ⛪ |
| `pollsit` | Pollsit | 📊 |
| `aftersignal` | AfterSignal | 📡 |
| `flubaweb` | Fluba Web | 🌐 |
| `airails` | AI-Rails | 🤖 |
| `blastybiz` | BlastyBiz | 📢 |

### Business Switcher UI

Built into `BlastyBiz-Dashboard.html`. A sticky bar below the header shows the active business. Tap it → bottom sheet slides up showing all businesses as cards with their visibility score and platform count. Tap any card to switch context. Tap ＋ to add a new business (routes to onboarding).

**Active business stored in:** `localStorage('ll_active_business')` — swap to Firestore:
```javascript
// Save active business
await setDoc(doc(db, 'users', uid), { activeBusiness: bizId }, { merge: true });

// Load active business on page init
const snap = await getDoc(doc(db, 'users', uid));
const activeBizId = snap.data().activeBusiness || null;
```

### Firestore Wiring for Switcher

When a user switches business, reload all dashboard data for the new `businessId`:
```javascript
async function loadBusinessContext(bizId) {
  // Business profile
  const biz = await getDoc(doc(db, 'businesses', bizId));
  
  // Platform connections
  const connections = await getDocs(
    query(collection(db, 'platformConnections'),
    where('businessId', '==', bizId))
  );
  
  // Recent publish jobs
  const jobs = await getDocs(
    query(collection(db, 'publishJobs'),
    where('businessId', '==', bizId),
    orderBy('createdAt', 'desc'),
    limit(10))
  );
  
  // Re-render all dashboard sections with this data
}
```

### Loading All Businesses for the Switcher Sheet
```javascript
// Load all businesses owned by the current user
const businesses = await getDocs(
  query(collection(db, 'businesses'),
  where('uid', '==', currentUser.uid))
);
```

### Adding a New Business
```javascript
// Create new business document
const newBizRef = doc(collection(db, 'businesses'));
await setDoc(newBizRef, {
  uid: currentUser.uid,
  name: '',
  onboarded: false,
  createdAt: serverTimestamp()
});

// Set as active and route to onboarding
await setDoc(doc(db, 'users', uid),
  { activeBusiness: newBizRef.id }, { merge: true });
window.location.href = 'BlastyBiz-Onboarding.html';
```

### Agency Plan Gating
```javascript
// Check business count before allowing add
const businesses = await getDocs(
  query(collection(db, 'businesses'), where('uid', '==', uid))
);
if (businesses.size >= 10) {
  // Show upgrade prompt or block
  return;
}
```

### BUSINESSES Array in Dashboard (Prototype → Firestore)
The `BUSINESSES` array in `BlastyBiz-Dashboard.html` is mock data. Replace the entire array and the `init()` call with a Firestore query on page load. All other switcher logic (renderSwitcherBar, renderSheet, switchBusiness, loadBusinessContext) is already wired correctly — only the data source changes.

---

## Notes for Rep

- **One concept, one name** — `BlastyBiz-Onboarding.html`, `BlastyBiz-Admin.html`, no version suffixes
- **Do not build duplicate pages** — no second wizard, no second dashboard, no second business profile form
- **`publishJobs` is the single source of truth** — customer status and admin queue both read from it only
- **Dave has 7 businesses** across Fluba ecosystem — all connect as separate business accounts under one Firebase project
- **Meta App Review** sometimes requires screen recording of the OAuth flow — have a working demo ready first
- **All API keys in Cloud Functions only** — never in any HTML file
- **localStorage structures already match Firestore** — direct swap, no restructure needed
- **Full AI prompt is in `runAdaptation()`** in `BlastyBiz.html` — preserve it exactly when moving to Cloud Function, do not rewrite it
- **Admin light theme is intentional** — `BlastyBiz-Admin-Queue-Manager.html` and `BlastyBiz-Admin-Logs.html` use white/slate, keep them that way
- **Listing Preview mock data** is Gulf Coast Pressure Washing — replace with dynamic `listingDrafts` data when wiring
- **Billing rule embedded in Admin Subscriptions:** do not delete customer data when subscription lapses — downgrade features, keep data, allow reactivation

---

*Built by Dave (Fluba Designs LLC) and Ghost, with Claude (Anthropic)*  
*12 HTML fixes applied and verified*  
*This document supersedes all previous handoff files*
