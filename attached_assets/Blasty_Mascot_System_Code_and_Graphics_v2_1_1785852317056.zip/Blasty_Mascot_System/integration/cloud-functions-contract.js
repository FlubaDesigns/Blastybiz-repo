// Node.js Cloud Functions pseudocode / contract. Keep model access server-side.
const ALLOWED_TRACKS=new Set(['local-service','retail','restaurant','professional-service','general']);
function assertAuth(req){if(!req.user)throw Object.assign(new Error('Unauthorized'),{status:401});}
function jsonOnlySchema(name){return {response_format:{type:'json_schema',json_schema:{name,strict:true,schema:{type:'object',additionalProperties:false}}}};}

exports.onboardClassify=async(req,res)=>{
  assertAuth(req); const answers=req.body?.answers||{};
  const result=await model.generate({system:`Classify the business. Return one approved track and only genuinely useful missing topics. Do not write conversational filler.`,input:answers,...jsonOnlySchema('classification')});
  if(!ALLOWED_TRACKS.has(result.track))result.track='general'; res.json(result);
};
exports.onboardAnalyze=async(req,res)=>{
  assertAuth(req); const result=await model.generate({system:`Analyze collected onboarding facts. Ask at most one follow-up, and only when omission would materially weaken the profile. Otherwise mark ready.`,input:req.body,...jsonOnlySchema('analysis')});res.json(result);
};
exports.onboardFinalize=async(req,res)=>{
  assertAuth(req); const result=await model.generate({system:`Create the final normalized business profile, description, globalMemory, targetCustomer, differentiators, keywords, tone guidance, and campaign themes. Never invent facts.`,input:req.body,...jsonOnlySchema('profile')});res.json(result);
};
