# Blasty Mascot System 2.1

A reusable layered-SVG mascot, hybrid onboarding framework, and local personality engine for BlastyBiz.

## 2.1 additions

- Friendly, Balanced, Minimal, and Silent personality modes.
- Adaptive verbosity: new users receive more guidance; experienced users receive only useful interventions.
- Local UX memory for sessions, completed steps, milestones, and last-seen state.
- Gaze system that looks toward fields, targets, or optionally the pointer.
- Contextual target highlighting and speech guidance.
- Confidence feedback and one-time milestone celebrations.
- Lightweight local confetti and richer idle/thinking behaviors.
- Lower-left launch-pad "garage" when parked at 50% opacity.
- Drag positioning and persistent restoration from version 2.0.
- No additional AI calls are required for these personality behaviors.

## Core files

- `assets/blasty-mascot.svg` — master layered SVG.
- `css/blasty-mascot.css` — state, placement, garage, gaze, and celebration visuals.
- `js/blasty-controller.js` — safe layer synchronization and placement controller.
- `js/blasty-personality.js` — adaptive personality, memory, milestones, and confidence.
- `js/hybrid-onboarding-engine.js` — deterministic + checkpoint AI onboarding.
- `config/blasty-guide.js` — local loose guide and branch definitions.
- `demo.html` — interactive 2.1 demonstration.

Serve the directory through HTTP; SVG loading through `fetch()` usually will not work from a `file://` URL.
