export const blastyGuide={
  voice:{accepted:['Perfect. I’ve got it.','Nice — that helps me understand {business}.','Great. That’s another important piece finished.']},
  required:[
    {id:'ownerName',prompt:'Hey! I’m Blasty. What should I call you?',validate:v=>String(v).trim().length<2?'Give me at least two characters.':null},
    {id:'email',prompt:a=>`Nice to meet you, ${String(a.ownerName).split(' ')[0]}! What’s your email?`,validate:v=>/^[^@]+@[^@]+\.[^@]+$/.test(v)?null:'That email does not look complete.'},
    {id:'bizName',prompt:'What business are we getting ready to market?',validate:v=>String(v).trim().length<2?'Enter the business name.':null},
    {id:'locationType',prompt:a=>`Is ${a.bizName} location-based, online, or both?`,validate:v=>['physical','online','both'].includes(v)?null:'Choose location-based, online, or both.'},
    {id:'cityState',prompt:a=>a.locationType==='online'?'Where is the business based, if anywhere?':`What city and state does ${a.bizName} serve?`,checkpoint:'classify'},
  ],
  tracks:{
    'local-service':['primaryServices','serviceArea','idealCustomer','differentiators','primaryGoal','businessStory'],
    'retail':['productTypes','salesChannels','shippingArea','idealCustomer','differentiators','primaryGoal'],
    'restaurant':['cuisine','serviceModes','signatureItems','serviceArea','idealCustomer','primaryGoal'],
    'professional-service':['specialties','engagementType','clientType','serviceArea','differentiators','primaryGoal'],
    'general':['offering','idealCustomer','serviceArea','differentiators','primaryGoal','businessStory']
  },
  steps:{
    primaryServices:{id:'primaryServices',prompt:'What services do customers hire you for most?'},serviceArea:{id:'serviceArea',prompt:'How far do you travel or what area do you serve?'},idealCustomer:{id:'idealCustomer',prompt:'Who is the customer you most want to reach?'},differentiators:{id:'differentiators',prompt:'What makes customers choose you instead of someone else?'},primaryGoal:{id:'primaryGoal',prompt:'What should your marketing accomplish first?',checkpoint:'analyze'},businessStory:{id:'businessStory',prompt:'Is there a short story or fact that helps people trust the business?'},productTypes:{id:'productTypes',prompt:'What are the main products or product categories?'},salesChannels:{id:'salesChannels',prompt:'Where can customers buy from you?'},shippingArea:{id:'shippingArea',prompt:'Where do you deliver or ship?'},cuisine:{id:'cuisine',prompt:'What kind of food do you serve?'},serviceModes:{id:'serviceModes',prompt:'Do you offer dine-in, pickup, delivery, catering, or a mix?'},signatureItems:{id:'signatureItems',prompt:'What are the dishes or items people should know you for?'},specialties:{id:'specialties',prompt:'What are your main specialties?'},engagementType:{id:'engagementType',prompt:'Do clients usually hire you once or work with you over time?'},clientType:{id:'clientType',prompt:'What type of clients do you work with?'},offering:{id:'offering',prompt:'In plain language, what does the business offer?'}
  }
};
